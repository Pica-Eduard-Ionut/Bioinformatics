Pica Eduard-Ionut
